/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package action provide the implementation of action module.
package action

import (
	"context"

	"git.huawei.com/poissonsearch/wienerchain/proto/common"
	"git.huawei.com/poissonsearch/wienerchain/proto/nodeservice"
	"google.golang.org/grpc"
)

// ChainAction is the action for chain operations.
type ChainAction struct {
	client nodeservice.ChainManagerClient
}

// NewChainAction is used to create chain action instance with a grpc client connection.
func NewChainAction(cc grpc.ClientConnInterface) *ChainAction {
	client := nodeservice.NewChainManagerClient(cc)
	return &ChainAction{client: client}
}

// JoinChain is used to send join chain request raw message by grpc.
func (chainAction *ChainAction) JoinChain(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return chainAction.client.CreateChain(context.Background(), rawMsg)
}

// QuitChain is used to send quit chain request raw message by grpc.
func (chainAction *ChainAction) QuitChain(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return chainAction.client.DeleteChain(context.Background(), rawMsg)
}

// QueryChain is used to send query chain request raw message by grpc.
func (chainAction *ChainAction) QueryChain(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return chainAction.client.QueryChainInfo(context.Background(), rawMsg)
}

// QueryAllChains is used to send query all chains request raw message by grpc.
func (chainAction *ChainAction) QueryAllChains(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return chainAction.client.QueryAllChainInfos(context.Background(), rawMsg)
}
