/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package action

import (
	"context"
	"fmt"

	"git.huawei.com/poissonsearch/wienerchain/proto/common"
	"git.huawei.com/poissonsearch/wienerchain/proto/nodeservice"
	"github.com/golang/protobuf/proto"
	"google.golang.org/grpc"
)

// EventAction is the action for event operations.
type EventAction struct {
	client nodeservice.EventServiceClient
}

// NewEventAction is used to create event action instance with a grpc client connection.
func NewEventAction(cc grpc.ClientConnInterface) *EventAction {
	client := nodeservice.NewEventServiceClient(cc)
	return &EventAction{client: client}
}

// Listen is used to register result event to server and get the register result client.
func (eventAction *EventAction) Listen(chainID string) (nodeservice.EventService_RegisterResultEventClient, error) {
	in := &common.RawMessage{}
	startPoint := &nodeservice.EventStartPoint{}
	startPoint.ChainId = chainID
	startPoint.Type = nodeservice.StartPointType_LATEST
	bytes, err := proto.Marshal(startPoint)
	if err != nil {
		return nil, fmt.Errorf("marshal EventStartPoint error: %v", err)
	}
	in.Payload = bytes

	event, err := eventAction.client.RegisterResultEvent(context.Background(), in)
	if err != nil {
		return nil, fmt.Errorf("event action RegisterResultEvent failed:%v", err)
	}
	return event, nil
}
