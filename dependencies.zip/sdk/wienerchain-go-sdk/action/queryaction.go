/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package action

import (
	"context"

	"git.huawei.com/poissonsearch/wienerchain/proto/common"
	"git.huawei.com/poissonsearch/wienerchain/proto/nodeservice"
	"google.golang.org/grpc"
)

// QueryAction is the action for query operations.
type QueryAction struct {
	clientServiceClient nodeservice.ChainServiceClient
	nodeServiceClient   nodeservice.NodeServiceClient
	voteManagerClient   nodeservice.VoteManagerClient
}

// NewQueryAction is used to create query action instance with a grpc client connection.
func NewQueryAction(cc grpc.ClientConnInterface) *QueryAction {
	clientServiceClient := nodeservice.NewChainServiceClient(cc)
	nodeServiceClient := nodeservice.NewNodeServiceClient(cc.(*grpc.ClientConn))
	voteManagerClient := nodeservice.NewVoteManagerClient(cc)
	return &QueryAction{clientServiceClient: clientServiceClient, nodeServiceClient: nodeServiceClient,
		voteManagerClient: voteManagerClient}
}

// GetLatestChainState is used to send get latest chain request raw message by grpc.
func (action *QueryAction) GetLatestChainState(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return action.clientServiceClient.GetLatestChainState(context.Background(), rawMsg)
}

// GetBlockByNum is used to send get block by number request raw message by grpc.
func (action *QueryAction) GetBlockByNum(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return action.clientServiceClient.GetBlockByNum(context.Background(), rawMsg)
}

// GetTransactionByID is used to send get transaction by id request raw message by grpc.
func (action *QueryAction) GetTransactionByID(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return action.clientServiceClient.GetTransactionByID(context.Background(), rawMsg)
}

// GetBlockByTxID is used to send get block by transaction id request raw message by grpc.
func (action *QueryAction) GetBlockByTxID(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return action.clientServiceClient.GetBlockByTxID(context.Background(), rawMsg)
}

// GetTxByTxID is used to send get transaction by transaction id request raw message by grpc.
func (action *QueryAction) GetTxByTxID(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return action.clientServiceClient.GetTransactionByID(context.Background(), rawMsg)
}

// GetContractInfo is used to send get contract info request raw message by grpc.
func (action *QueryAction) GetContractInfo(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return action.clientServiceClient.GetContractInfo(context.Background(), rawMsg)
}

// GetNode is used to send get node request raw message by grpc.
func (action *QueryAction) GetNode(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return action.nodeServiceClient.GetOrgNodes(context.Background(), rawMsg)
}

// GetVote is used to send get vote request raw message by grpc.
func (action *QueryAction) GetVote(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return action.voteManagerClient.Query(context.Background(), rawMsg)
}
