/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package action

import (
	"context"

	"git.huawei.com/poissonsearch/wienerchain/proto/common"
	"git.huawei.com/poissonsearch/wienerchain/proto/nodeservice"
	"google.golang.org/grpc"
)

// ContractAction is the action for contract operations.
type ContractAction struct {
	contractClient          nodeservice.ContractClient
	transactionSenderClient nodeservice.TransactionSenderClient
}

// NewContractAction is used to create contract action instance with a grpc client connection.
func NewContractAction(cc grpc.ClientConnInterface) *ContractAction {
	contractClient := nodeservice.NewContractClient(cc)
	transactionSenderClient := nodeservice.NewTransactionSenderClient(cc)
	return &ContractAction{contractClient: contractClient, transactionSenderClient: transactionSenderClient}
}

// Invoke is used to send invoke request raw message to contract by grpc.
func (contractAction *ContractAction) Invoke(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return contractAction.contractClient.Invoke(context.Background(), rawMsg)
}

// ContractImport is used to send import contract request raw message by grpc.
func (contractAction *ContractAction) ContractImport(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return contractAction.contractClient.Import(context.Background(), rawMsg)
}

// Transaction is used to send transaction request raw message by grpc.
func (contractAction *ContractAction) Transaction(rawMsg *common.RawMessage) (*common.RawMessage, error) {
	return contractAction.transactionSenderClient.SendTransaction(context.Background(), rawMsg)
}
