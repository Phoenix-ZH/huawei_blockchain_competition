/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package client provide the implementation of client module, which is the entrance of go sdk.
package client

import (
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"io/ioutil"
	"path/filepath"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/node"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"
	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr/cryptoimpl"
	"google.golang.org/grpc/credentials"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/config"
	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/rawmessage"
)

// GatewayClient is the definition of gateway client.
type GatewayClient struct {
	ChainRawMessage     *rawmessage.ChainRawMessage
	ContractRawMessage  *rawmessage.ContractRawMessage
	LifecycleRawMessage *rawmessage.LifecycleRawMessage
	QueryRawMessage     *rawmessage.QueryRawMessage
	Nodes               map[string]*node.WNode
}

// NewGatewayClient is used to create an instance of gateway client by specifying the config file path.
func NewGatewayClient(configPath string) (*GatewayClient, error) {
	config, err := config.NewClientConfig(configPath)
	if err != nil {
		return nil, fmt.Errorf("load config file error: %v", err)
	}

	crypto := getCrypto(config)
	msgBuilder, err := rawmessage.NewMsgBuilderImpl(crypto)
	if err != nil {
		return nil, fmt.Errorf("new MsgBuilderImpl error: %v", err)
	}

	chainRawMessage := rawmessage.NewChainRawMessage(msgBuilder, crypto)
	contractRawMessage := rawmessage.NewContractRawMessage(msgBuilder)
	lifecycleRawMessage := rawmessage.NewLifecycleRawMessage(msgBuilder, crypto)
	queryRawMessage := rawmessage.NewQueryRawMessage(msgBuilder)

	nodes, err := getNodes(config)
	if err != nil {
		return nil, fmt.Errorf("get nodes error: %v", err)
	}

	return &GatewayClient{ChainRawMessage: chainRawMessage, ContractRawMessage: contractRawMessage,
		LifecycleRawMessage: lifecycleRawMessage, QueryRawMessage: queryRawMessage, Nodes: nodes}, nil
}

func getNodes(c *config.ClientConfig) (map[string]*node.WNode, error) {
	nodes := make(map[string]*node.WNode)
	for _, n := range c.Nodes {
		var transportCreds credentials.TransportCredentials
		var err error
		tlsEnable := c.Client.TLS.Enable
		if tlsEnable {
			transportCreds, err = getSslContext(c)
			if err != nil {
				return nil, fmt.Errorf("get ssl context error: %v", err)
			}
		}
		var wnode *node.WNode
		wnode, err = node.NewNode(n, tlsEnable, transportCreds)
		if err != nil {
			return nil, fmt.Errorf("new node error: %v", err)
		}
		nodes[n.ID] = wnode
	}
	return nodes, nil
}

func getCrypto(c *config.ClientConfig) cryptomgr.Crypto {
	return cryptoimpl.NewCrypto(c.Client.Type, c.Client.Identity.CertPath, c.Client.Identity.KeyPath)
}

func getSslContext(c *config.ClientConfig) (credentials.TransportCredentials, error) {
	cert, err := tls.LoadX509KeyPair(c.Client.TLS.CertPath, c.Client.TLS.KeyPath)
	if err != nil {
		return nil, fmt.Errorf("load x509 key pair error: %v", err)
	}

	certPool := x509.NewCertPool()
	for _, rootCertPath := range c.Client.TLS.RootPath {
		bs, err := ioutil.ReadFile(filepath.Clean(rootCertPath))
		if err != nil {
			return nil, fmt.Errorf("read file failed, file: %v, error: %v", rootCertPath, err)
		}
		if !certPool.AppendCertsFromPEM(bs) {
			return nil, fmt.Errorf("fail to append test ca")
		}
	}

	transportCreds := credentials.NewTLS(&tls.Config{
		Certificates:             []tls.Certificate{cert},
		RootCAs:                  certPool,
		MinVersion:               tls.VersionTLS12,
		PreferServerCipherSuites: true,
		CipherSuites: []uint16{
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
		},
	})
	return transportCreds, nil
}
