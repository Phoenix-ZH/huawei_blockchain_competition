/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package node is the definition of node.
package node

import (
	"fmt"
	"strconv"

	"google.golang.org/grpc/credentials"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/config"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/action"
	"google.golang.org/grpc"
)

// WNode is the definition of WNode.
type WNode struct {
	*config.Node
	ChainAction    *action.ChainAction
	ContractAction *action.ContractAction
	EventAction    *action.EventAction
	QueryAction    *action.QueryAction
}

// NewNode is used to create a wnode proxy.
func NewNode(node *config.Node, tlsEnable bool, transportCreds credentials.TransportCredentials) (*WNode, error) {
	ipAddr := node.Host + ":" + strconv.Itoa(node.Port)
	options := getOpts(tlsEnable, transportCreds)
	cc, err := grpc.Dial(ipAddr, options...)
	if err != nil {
		return nil, fmt.Errorf("new node error: %v", err)
	}

	return &WNode{node, action.NewChainAction(cc), action.NewContractAction(cc),
		action.NewEventAction(cc), action.NewQueryAction(cc)}, nil
}

func getOpts(tlsEnable bool, transportCreds credentials.TransportCredentials) []grpc.DialOption {
	var options []grpc.DialOption
	options = append(options, grpc.WithBlock())
	if tlsEnable {
		options = append(options, grpc.WithTransportCredentials(transportCreds))
	} else {
		options = append(options, grpc.WithInsecure())
		fmt.Printf("default insecure for go sdk.....\n")
	}

	return options
}
