/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package config provide the implementation of config module, which is used to parse config file.
package config

import (
	"fmt"
	"os"

	"github.com/spf13/viper"
)

// ClientConfig is the definition of config.
type ClientConfig struct {
	Client Client
	Nodes  []*Node
}

// Client is the definition of Client.
type Client struct {
	Type     string
	Identity Identity
	TLS      TLS
}

// Identity is the definition fo Identity.
type Identity struct {
	CertPath string
	KeyPath  string
}

// TLS is the definition of TLS.
type TLS struct {
	Enable   bool
	CertPath string
	KeyPath  string
	RootPath []string
}

// Node is the definition of Node.
type Node struct {
	ID   string
	Host string
	Port int
}

// NewClientConfig is used to load config file and parse config file to ClientConfig struct.
func NewClientConfig(configPath string) (*ClientConfig, error) {
	_, errMsg := os.Stat(configPath)
	if errMsg != nil {
		return nil, fmt.Errorf("CfgFilePath does not exist: %s, %v", configPath, errMsg)
	}
	v := viper.New()
	v.SetConfigFile(configPath)
	v.SetConfigType("yaml")

	if err := v.ReadInConfig(); err != nil {
		return nil, err
	}

	gatewayConfig := &ClientConfig{}
	errMsg = unmarshal(v, &gatewayConfig)
	if errMsg != nil {
		return nil, fmt.Errorf("error unmarshaling config into struct: %v", errMsg)
	}

	return gatewayConfig, nil
}
