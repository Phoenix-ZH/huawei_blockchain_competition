/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package config

import (
	"encoding/json"
	"fmt"
	"sort"

	"github.com/mitchellh/mapstructure"

	"github.com/spf13/viper"
)

type viperGetter func(key string) interface{}

func getKeysRecursively(base string, getKey viperGetter, nodeKeys map[string]interface{}) map[string]interface{} {
	result := make(map[string]interface{})
	for key := range nodeKeys {
		fqKey := base + key
		val := getKey(fqKey)
		if m, ok := val.(map[interface{}]interface{}); ok {
			tmp := make(map[string]interface{})
			for ik, iv := range m {
				cik, ok := ik.(string)
				if !ok {
					panic("Non string key-entry")
				}
				tmp[cik] = iv
			}
			result[key] = getKeysRecursively(fqKey+".", getKey, tmp)
		} else if m, ok := val.(map[string]interface{}); ok {
			result[key] = getKeysRecursively(fqKey+".", getKey, m)
		} else if m, ok := unmarshalJSON(val); ok {
			result[key] = m
		} else {
			if val == nil {
				fileSubKey := fqKey + ".File"
				fileVal := getKey(fileSubKey)
				if fileVal != nil {
					result[key] = map[string]interface{}{"File": fileVal}
					continue
				}
			}
			result[key] = val
		}
	}
	return result
}

func unmarshalJSON(val interface{}) (map[string]string, bool) {
	mp := map[string]string{}
	s, ok := val.(string)
	if !ok {
		return nil, false
	}
	err := json.Unmarshal([]byte(s), &mp)
	if err != nil {
		return nil, false
	}
	return mp, true
}

// unmarshal is intended to unmarshal a config file into a structure
func unmarshal(v *viper.Viper, output interface{}) error {
	baseKeys := v.AllSettings()
	leafKeys := getKeysRecursively("", v.Get, baseKeys)
	if err := processNodes(leafKeys); err != nil {
		return fmt.Errorf("process nodes error: %v", err)
	}
	return mapstructure.Decode(leafKeys, output)
}

// unmarshal is intended to unmarshal a config file into a structure
func unmarshalGenesisConfig(v *viper.Viper, output interface{}) error {
	baseKeys := v.AllSettings()
	leafKeys := getKeysRecursively("", v.Get, baseKeys)
	if err := processGenesisBlock(leafKeys); err != nil {
		return fmt.Errorf("process genesis block error: %v", err)
	}
	return mapstructure.Decode(leafKeys, output)
}

func processGenesisBlock(configMap map[string]interface{}) error {
	genesisBlockMapTmp := configMap["genesisblock"]
	genesisBlockMap, ok := genesisBlockMapTmp.(map[string]interface{})
	if !ok {
		return fmt.Errorf("type assert error: map[string]interface{}")
	}
	consentersMapTmp := genesisBlockMap["consenters"]
	consentersMap, ok := consentersMapTmp.(map[string]interface{})
	if !ok {
		return fmt.Errorf("type assert error: map[string]interface{}")
	}
	consentersArray, err := convertMap2Array(consentersMap)
	if err != nil {
		return fmt.Errorf("convert map to array error: %v", err)
	}
	genesisBlockMap["consenters"] = consentersArray

	organizationsMapTmp := genesisBlockMap["organizations"]
	organizationsMap, ok := organizationsMapTmp.(map[string]interface{})
	if !ok {
		return fmt.Errorf("type assert error: map[string]interface{}")
	}
	organizationsArray, err := convertMap2Array(organizationsMap)
	if err != nil {
		return fmt.Errorf("convert map to array error: %v", err)
	}
	genesisBlockMap["organizations"] = organizationsArray

	leTimeoutLowerLimit := genesisBlockMap["le_timeout_lower_limit"]
	leTimeoutUpperLimit := genesisBlockMap["le_timeout_upper_limit"]
	hbTimeout := genesisBlockMap["hb_timeout"]

	genesisBlockMap["letimeoutlowerlimit"] = leTimeoutLowerLimit
	genesisBlockMap["letimeoutupperlimit"] = leTimeoutUpperLimit
	genesisBlockMap["hbtimeout"] = hbTimeout
	return nil
}

func processNodes(configMap map[string]interface{}) error {
	nodesMapTmp := configMap["nodes"]
	nodesMap, ok := nodesMapTmp.(map[string]interface{})
	if !ok {
		return fmt.Errorf("type assert error: map[string]interface{}")
	}
	nodes, err := convertMap2Array(nodesMap)
	if err != nil {
		return fmt.Errorf("convert map to array error: %v", err)
	}
	configMap["nodes"] = nodes
	return nil
}

func convertMap2Array(m map[string]interface{}) ([]interface{}, error) {
	var keyArray []string
	for key := range m {
		keyArray = append(keyArray, key)
	}
	sort.Strings(keyArray)

	var array []interface{}
	for _, key := range keyArray {
		value := m[key]
		e, ok := value.(map[string]interface{})
		if !ok {
			return nil, fmt.Errorf("type assert error: map[string]interface{}")
		}
		e["ID"] = key
		array = append(array, e)
	}
	return array, nil
}
