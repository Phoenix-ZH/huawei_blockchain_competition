/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package config

import (
	"fmt"
	"os"

	"github.com/spf13/viper"
)

// GenesisConfig is the definition of GenesisConfig.
type GenesisConfig struct {
	GenesisBlock GenesisBlock
}

// GenesisBlock is the definition of GenesisBlock.
type GenesisBlock struct {
	Type                string
	DBType              string
	MaxTxCount          uint64
	MaxBlockSize        uint64
	PackageTimeout      uint64
	F                   uint64
	LeTimeoutLowerLimit uint64
	LeTimeoutUpperLimit uint64
	HbTimeout           uint64
	ReqTimeout          uint64
	Policy              Policy
	Consenters          []ConsenterNode
	Organizations       []Organization
}

// Solo is the definition of Solo consensus.
type Solo struct {
}

// Raft is the definition of Raft consensus.
type Raft struct {
	LeTimeoutLowerLimit int
	LeTimeoutUpperLimit int
	HbTimeout           int
}

// Flic is the definition of Flic consensus.
type Flic struct {
}

// Policy is the definition of proposal policy.
type Policy struct {
	Config    string
	Lifecycle string
}

// ConsenterNode is the definition of consenter node.
type ConsenterNode struct {
	ID      string
	Org     string
	Host    string
	Port    uint64
	ReeCert string
	TeeCert string
}

// Organization is the definition of Organization.
type Organization struct {
	ID        string
	AdminCert string
	RootCert  string
}

// NewGenesisConfig is used to new an instance of genesis config
func NewGenesisConfig(genesisConfigPath string) (*GenesisConfig, error) {
	_, errMsg := os.Stat(genesisConfigPath)
	if errMsg != nil {
		return nil, fmt.Errorf("CfgFilePath does not exist: %s, %v", genesisConfigPath, errMsg)
	}
	v := viper.New()
	v.SetConfigFile(genesisConfigPath)
	v.SetConfigType("yaml")

	if err := v.ReadInConfig(); err != nil {
		return nil, err
	}

	genesisConfig := &GenesisConfig{}

	errMsg = unmarshalGenesisConfig(v, &genesisConfig)
	if errMsg != nil {
		return nil, fmt.Errorf("error unmarshaling config into struct: %v", errMsg)
	}
	return genesisConfig, nil
}
