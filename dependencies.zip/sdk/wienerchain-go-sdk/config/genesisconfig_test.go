/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package config

import (
	"os"
	"testing"
)

func Test_Genesis_Config(t *testing.T) {
	configFile := "../../gateway/conf/genesis-config.yaml.template"
	_, errMsg := os.Stat(configFile)
	if errMsg != nil {
		t.Errorf("CfgFilePath %s does not exist", configFile)
		return
	}

	cfg, err := NewGenesisConfig(configFile)
	if err != nil {
		t.Errorf("new genesis config error: %v\n", err)
		return
	}

	t.Logf("genesis config: %v\n", cfg.GenesisBlock)
}
