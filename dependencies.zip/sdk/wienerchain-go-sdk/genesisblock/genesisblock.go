/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package genesisblock is the definition of parse genesis block from genesis config file.
package genesisblock

import (
	"fmt"
	"io/ioutil"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/config"

	"git.huawei.com/poissonsearch/wienerchain/proto/common"
	"git.huawei.com/poissonsearch/wienerchain/proto/consensus"
	"github.com/golang/protobuf/proto"
)

// GetChainConfig is used to parse chain config from config file.
func GetChainConfig(c *config.GenesisConfig, chainID string) (*common.ChainConfig, error) {
	var dbType common.DBType
	switch c.GenesisBlock.DBType {
	case "leveldb":
		dbType = common.DBType_LEVELDB
	case "mysql":
		dbType = common.DBType_MYSQL
	case "postgresql":
		dbType = common.DBType_POSTGRESQL
	default:
		dbType = common.DBType_LEVELDB
	}

	sysConsensus, err := getConsensus(c)
	if err != nil {
		return nil, fmt.Errorf("get sys consensus error: %v", err)
	}
	organs, err := getOrganizations(c)
	if err != nil {
		return nil, fmt.Errorf("get organizations error: %v", err)
	}

	consensusByte, err := proto.Marshal(sysConsensus)
	if err != nil {
		return nil, fmt.Errorf("chain config marshal error: %v", err)
	}
	chainConfig := &common.ChainConfig{
		ChainId:         chainID,
		DbType:          dbType,
		Organizations:   organs,
		Consensus:       consensusByte,
		ConfigPolicy:    c.GenesisBlock.Policy.Config,
		LifecyclePolicy: c.GenesisBlock.Policy.Lifecycle}
	return chainConfig, nil
}

func getConsensus(c *config.GenesisConfig) (*consensus.SysConsensus, error) {
	sysConsensus := &consensus.SysConsensus{MaxTransactionCount: c.GenesisBlock.MaxBlockSize,
		MaxBlockSize: c.GenesisBlock.MaxBlockSize, PackageTimeout: c.GenesisBlock.PackageTimeout}
	switch c.GenesisBlock.Type {
	case "solo":
		solo := &consensus.SysConsensus_Solo{Solo: &consensus.SoloType{}}
		sysConsensus.Type = solo
	case "flic":
		flic := &consensus.SysConsensus_Flic{Flic: &consensus.FlicType{F: c.GenesisBlock.F,
			ReqTimeout: c.GenesisBlock.ReqTimeout}}
		sysConsensus.Type = flic
	case "raft":
		raft := &consensus.SysConsensus_Raft{Raft: &consensus.RaftType{
			LeTimeoutLowerLimit: c.GenesisBlock.LeTimeoutLowerLimit,
			LeTimeoutUpperLimit: c.GenesisBlock.LeTimeoutUpperLimit,
			HbTimeout:           c.GenesisBlock.HbTimeout, ReqTimeout: c.GenesisBlock.ReqTimeout}}
		sysConsensus.Type = raft
	default:
		return nil, fmt.Errorf("not support consensus type: %v", c.GenesisBlock.Type)
	}

	var consenters []*consensus.Consenter
	for idx := range c.GenesisBlock.Consenters {
		consenterNode := c.GenesisBlock.Consenters[idx]
		reeCert, err := ioutil.ReadFile(consenterNode.ReeCert)
		if err != nil {
			return nil, fmt.Errorf("load certifacate error: %v", err)
		}
		consenter := &consensus.Consenter{Name: consenterNode.ID, Org: consenterNode.Org, Addr: consenterNode.Host,
			Port: consenterNode.Port, ReeCert: reeCert}
		consenters = append(consenters, consenter)
	}
	sysConsensus.Consenter = consenters
	return sysConsensus, nil
}

func getOrganizations(c *config.GenesisConfig) ([]*common.Organization, error) {
	var organs []*common.Organization
	for idx := range c.GenesisBlock.Organizations {
		organNode := c.GenesisBlock.Organizations[idx]
		rootCert, err := ioutil.ReadFile(organNode.RootCert)
		if err != nil {
			return nil, fmt.Errorf("load root certifacate error: %v", err)
		}
		adminCert, err := ioutil.ReadFile(organNode.AdminCert)
		if err != nil {
			return nil, fmt.Errorf("load admin certifacate error: %v", err)
		}
		organ := &common.Organization{Name: organNode.ID, RootCert: rootCert,
			AdminCert: adminCert}
		organs = append(organs, organ)
	}
	return organs, nil
}
