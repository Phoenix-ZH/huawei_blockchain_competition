/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package rawmessage

import (
	"fmt"

	"git.huawei.com/poissonsearch/wienerchain/proto/common"
	"git.huawei.com/poissonsearch/wienerchain/proto/nodeservice"
	"github.com/golang/protobuf/proto"
)

// ContractRawMessage is the definition of ContractRawMessage.
type ContractRawMessage struct {
	builder MsgBuilder
}

// NewContractRawMessage is used to create an instance of contract raw message by specifying an message builder.
func NewContractRawMessage(builder MsgBuilder) *ContractRawMessage {
	return &ContractRawMessage{builder: builder}
}

// BuildInvokeMessage is used to build invoke raw message for send transaction proposal.
func (msg *ContractRawMessage) BuildInvokeMessage(chainID string, txID string, name string, function string,
	args []string) (*common.RawMessage, error) {
	var argsArrays [][]byte
	for _, arg := range args {
		argsArrays = append(argsArrays, []byte(arg))
	}
	contractInvocation := &common.ContractInvocation{ContractName: name, FuncName: function, Args: argsArrays}
	txHeader := &common.TxHeader{Type: common.TxType_COMMON_TRANSACTION, ChainId: chainID, TxId: txID}
	invocation := &nodeservice.Invocation{Header: txHeader, Parameters: contractInvocation}
	payload, err := proto.Marshal(invocation)
	if err != nil {
		return nil, fmt.Errorf("marshal invocation error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildTransactionMessage is used to build transaction raw message for send transaction.
func (msg *ContractRawMessage) BuildTransactionMessage(rawMessages []*common.RawMessage) (*common.RawMessage, error) {
	var approvals []*common.Approval
	var payload []byte
	for _, rawMsg := range rawMessages {
		response := &common.Response{}
		if err := proto.Unmarshal(rawMsg.Payload, response); err != nil {
			return nil, fmt.Errorf("unmarshal raw message error: %v", err)
		}
		if response.Status != common.Status_SUCCESS {
			return nil, fmt.Errorf("invoke response status is: %v\n%v", response.Status.String(),
				response.StatusInfo)
		}
		tx := &common.Transaction{}
		if err := proto.Unmarshal(response.Payload, tx); err != nil {
			return nil, fmt.Errorf("unmarshal transaction error: %v", err)
		}
		if payload == nil {
			payload = tx.Payload
		} else if string(tx.Payload) != string(payload) {
			return nil, fmt.Errorf("payload of transactions are not the same")
		}

		approvals = append(approvals, tx.Approvals...)
	}
	tx := &common.Transaction{Payload: payload, Approvals: approvals}
	payload, err := proto.Marshal(tx)
	if err != nil {
		return nil, fmt.Errorf("marshal transaction error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}
