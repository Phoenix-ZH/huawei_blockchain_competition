/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package rawmessage

import (
	"fmt"
	"io/ioutil"
	"path/filepath"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"

	"git.huawei.com/poissonsearch/wienerchain/proto/common"
	"git.huawei.com/poissonsearch/wienerchain/proto/contract"
	"git.huawei.com/poissonsearch/wienerchain/proto/nodeservice"
	"github.com/golang/protobuf/proto"
)

// LifecycleRawMessage is the definition of LifecycleRawMessage.
type LifecycleRawMessage struct {
	builder MsgBuilder
	crypto  cryptomgr.Crypto
}

// Contract is the definition of contract.
type Contract struct {
	chainID string
	name    string
	version string
}

// NewLifecycleRawMessage is used to create an instance of lifecycle raw message by specifying an message builder.
func NewLifecycleRawMessage(builder MsgBuilder, crypto cryptomgr.Crypto) *LifecycleRawMessage {
	return &LifecycleRawMessage{builder: builder, crypto: crypto}
}

// NewContract is used to create an instance of contract by specifying chain id, contract name and contract version.
func NewContract(chainID string, name string, version string) *Contract {
	return &Contract{chainID: chainID, name: name, version: version}
}

// BuildImportRawMessage is used to build import raw message for import contract.
func (msg *LifecycleRawMessage) BuildImportRawMessage(c *Contract, path string,
	sandbox string) (*common.RawMessage, error) {
	codes, err := ioutil.ReadFile(filepath.Clean(path))
	if err != nil {
		return nil, fmt.Errorf("read contract code error: %v", err)
	}
	externalContractInfo := &contract.ExternalContractInfo{SandboxType: sandbox, Code: codes, SchemaVersion: c.version}
	contractInfoType := &nodeservice.ContractInfo_ExternalContractInfo{ExternalContractInfo: externalContractInfo}
	contractInfo := &nodeservice.ContractInfo{ChainId: c.chainID, ContractName: c.name, Type: contractInfoType}
	payload, err := proto.Marshal(contractInfo)
	if err != nil {
		return nil, fmt.Errorf("marshal contract info error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildVoteRawMessage is used to build vote raw message for vote contract.
func (msg *LifecycleRawMessage) BuildVoteRawMessage(c *Contract, desc string, policy string,
	txID string, historySupport bool) (*common.RawMessage, error) {
	rawMsg, err := msg.buildVoteRawMessage(c, desc, policy, txID, "", historySupport)
	if err != nil {
		return nil, fmt.Errorf("build vote raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildSQLVoteRawMessage is used to build SQL vote raw message for vote contract.
func (msg *LifecycleRawMessage) BuildSQLVoteRawMessage(c *Contract, desc string, policy string, txID string,
	schema string, historySupport bool) (*common.RawMessage, error) {
	rawMsg, err := msg.buildVoteRawMessage(c, desc, policy, txID, schema, historySupport)
	if err != nil {
		return nil, fmt.Errorf("build sql vote raw message error: %v", err)
	}
	return rawMsg, nil
}

func (msg *LifecycleRawMessage) buildVoteRawMessage(c *Contract, desc string, policy string, txID string,
	schema string, historySupport bool) (*common.RawMessage, error) {
	validatorExtensions := make(map[string][]byte)
	validatorExtensions["policy"] = []byte(policy)
	var contractDefinition *contract.ContractDefinition
	if schema == "" {
		contractDefinition = &contract.ContractDefinition{
			ContractName:        c.name,
			SchemaVersion:       c.version,
			SequenceNumber:      0,
			Description:         desc,
			HistorySupport:      historySupport,
			ApprovalValidator:   "default",
			ValidatorExtensions: validatorExtensions}
	} else {
		contractDefinition = &contract.ContractDefinition{
			ContractName:        c.name,
			SchemaVersion:       c.version,
			SequenceNumber:      0,
			Description:         desc,
			SqlDbSchema:         schema,
			HistorySupport:      historySupport,
			ApprovalValidator:   "default",
			ValidatorExtensions: validatorExtensions}
	}

	contractDefinitionBytes, err := proto.Marshal(contractDefinition)
	if err != nil {
		return nil, fmt.Errorf("marshal contract definition error: %v", err)
	}

	voteTxData := &common.VoteTxData{Handler: "lifecycle", Subject: c.name, Payload: contractDefinitionBytes}
	voteTxDataByte, err := proto.Marshal(voteTxData)
	if err != nil {
		return nil, fmt.Errorf("marshal vote tx data error: %v", err)
	}

	txHeader := &common.TxHeader{ChainId: c.chainID, TxId: txID, Type: common.TxType_VOTE_TRANSACTION}
	txPayload := &common.TxPayload{Header: txHeader, Data: voteTxDataByte}
	txPayloadBytes, err := proto.Marshal(txPayload)
	if err != nil {
		return nil, fmt.Errorf("marshal tx payload error: %v", err)
	}

	certBytes, err := msg.crypto.GetCertificate()
	if err != nil {
		return nil, fmt.Errorf("get certificate error: %v", err)
	}
	sign, err := msg.crypto.Sign(txPayloadBytes)
	if err != nil {
		return nil, fmt.Errorf("sign error: %v", err)
	}
	approval := &common.Approval{Cert: certBytes, Sign: sign}
	var approvals []*common.Approval
	approvals = append(approvals, approval)
	tx := &common.Transaction{Payload: txPayloadBytes, Approvals: approvals}
	payload, err := proto.Marshal(tx)
	if err != nil {
		return nil, fmt.Errorf("marshal transaction error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}
