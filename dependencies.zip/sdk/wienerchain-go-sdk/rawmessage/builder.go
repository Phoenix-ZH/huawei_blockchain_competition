/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package rawmessage is the implementation of raw message, which is used to build raw message for grpc request.
package rawmessage

import (
	"fmt"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"

	"git.huawei.com/poissonsearch/wienerchain/proto/common"
)

// MsgBuilder is the interface of base raw message builder.
type MsgBuilder interface {
	GetRawMessage(payload []byte) (*common.RawMessage, error)
}

// MsgBuilderImpl is the definition of MsgBuilderImpl.
type MsgBuilderImpl struct {
	crypto cryptomgr.Crypto
}

// NewMsgBuilderImpl is used to create an instance of MsgBuilderImpl by specifying crypto.
func NewMsgBuilderImpl(crypto cryptomgr.Crypto) (*MsgBuilderImpl, error) {
	msgBuilder := &MsgBuilderImpl{crypto: crypto}
	return msgBuilder, nil
}

// GetRawMessage is used to generate raw message for the payload.
func (builder *MsgBuilderImpl) GetRawMessage(payload []byte) (*common.RawMessage, error) {
	cert, err := builder.crypto.GetCertificate()
	if err != nil {
		return nil, fmt.Errorf("get certificate error: %v", err)
	}

	sign, err := builder.crypto.Sign(payload)
	if err != nil {
		return nil, fmt.Errorf("sign payload error: %v", err)
	}
	rawMessage := &common.RawMessage{
		Signature: &common.RawMessage_Signature{
			Cert: cert,
			Sign: sign,
		},
		Payload: payload,
	}

	return rawMessage, nil
}
