/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package rawmessage

import (
	"fmt"

	"git.huawei.com/poissonsearch/wienerchain/proto/common"
	"git.huawei.com/poissonsearch/wienerchain/proto/nodeservice"
	"github.com/golang/protobuf/proto"
)

const (
	// ConfigHandler is the config handler string
	ConfigHandler = "config"
	// LifecycleHandler is the lifecycle handler string
	LifecycleHandler = "lifecycle"
)

// QueryRawMessage is the definition of QueryRawMessage.
type QueryRawMessage struct {
	builder MsgBuilder
}

// NewQueryRawMessage is used to create an instance of query raw message by specifying an message builder.
func NewQueryRawMessage(builder MsgBuilder) *QueryRawMessage {
	return &QueryRawMessage{builder: builder}
}

// BuildTxRawMessage is used to build tx raw message for query transaction.
func (msg *QueryRawMessage) BuildTxRawMessage(chainID string, txID string) (*common.RawMessage, error) {
	request := &nodeservice.ChainServiceRequest{ChainId: chainID, Type: &nodeservice.ChainServiceRequest_TxId{TxId: txID}}
	payload, err := proto.Marshal(request)
	if err != nil {
		return nil, fmt.Errorf("marshal chain service request error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildLatestChainStateRawMessage is used to build latest chain state raw message for query latest chain state.
func (msg *QueryRawMessage) BuildLatestChainStateRawMessage(chainID string) (*common.RawMessage, error) {
	request := &nodeservice.ChainServiceRequest{ChainId: chainID}
	payload, err := proto.Marshal(request)
	if err != nil {
		return nil, fmt.Errorf("marshal chain service request error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildBlockRawMessage is used to build block raw message for query block.
func (msg *QueryRawMessage) BuildBlockRawMessage(chainID string, blockNum uint64) (*common.RawMessage, error) {
	request := &nodeservice.ChainServiceRequest{ChainId: chainID,
		Type: &nodeservice.ChainServiceRequest_BlockNum{BlockNum: blockNum}}
	payload, err := proto.Marshal(request)
	if err != nil {
		return nil, fmt.Errorf("marshal chain service request error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildContractRawMessage is used to build contract raw message for query contract.
func (msg *QueryRawMessage) BuildContractRawMessage(chainID string, contract string) (*common.RawMessage, error) {
	request := &nodeservice.ChainServiceRequest{ChainId: chainID,
		Type: &nodeservice.ChainServiceRequest_Contract{Contract: contract}}
	payload, err := proto.Marshal(request)
	if err != nil {
		return nil, fmt.Errorf("marshal chain service request error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildNodeRawMessage is used to build node raw message for query node.
func (msg *QueryRawMessage) BuildNodeRawMessage() (*common.RawMessage, error) {
	request := &nodeservice.ChainServiceRequest{}
	payload, err := proto.Marshal(request)
	if err != nil {
		return nil, fmt.Errorf("marshal chain service request error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildQueryChainUpdateVoteRawMessage is used to build query chain update vote raw message for query chain update vote.
func (msg *QueryRawMessage) BuildQueryChainUpdateVoteRawMessage(chainID string) (*common.RawMessage, error) {
	request := &nodeservice.VoteQuery{ChainId: chainID, Handler: ConfigHandler}
	payload, err := proto.Marshal(request)
	if err != nil {
		return nil, fmt.Errorf("marshal vote query error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildQueryLifecycleVoteRawMessage is used to build query lifecycle vote raw message for query lifecycle vote.
func (msg *QueryRawMessage) BuildQueryLifecycleVoteRawMessage(chainID string,
	contract string) (*common.RawMessage, error) {
	request := &nodeservice.VoteQuery{ChainId: chainID, Handler: LifecycleHandler, Subject: contract}
	payload, err := proto.Marshal(request)
	if err != nil {
		return nil, fmt.Errorf("marshal vote query error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}
