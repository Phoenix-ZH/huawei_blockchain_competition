/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package rawmessage

import (
	"fmt"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/genesisblock"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"
	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr/cryptoimpl"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/config"

	"git.huawei.com/poissonsearch/wienerchain/proto/common"
	"git.huawei.com/poissonsearch/wienerchain/proto/nodeservice"
	"github.com/golang/protobuf/proto"
)

const (
	// HANDLER is the key value of handler.
	HANDLER = "config"
	// BlockNumber is the specified block number.
	BlockNumber = 0
)

// ChainRawMessage is the definition of ChainRawMessage.
type ChainRawMessage struct {
	builder MsgBuilder
	crypto  cryptomgr.Crypto
}

// NewChainRawMessage is used to create an instance of chain raw message by specifying an message builder.
func NewChainRawMessage(builder MsgBuilder, crypto cryptomgr.Crypto) *ChainRawMessage {
	return &ChainRawMessage{builder: builder, crypto: crypto}
}

// BuildGenesisBlock is used to build genesis block for create chain by specifying chain id, transaction id and genesis
// block config file path.
func (msg *ChainRawMessage) BuildGenesisBlock(chainID string, txID string,
	genesisConfigPath string) (*common.Block, error) {
	tx, err := msg.getVoteTransaction(chainID, txID, genesisConfigPath)
	if err != nil {
		return nil, fmt.Errorf("get transaction error: %v", err)
	}

	txs := make([]*common.Transaction, 1)
	txs[0] = tx
	blockBody := &common.BlockBody{Transactions: txs}
	bodyBytes, err := proto.Marshal(blockBody)
	if err != nil {
		return nil, fmt.Errorf("block body marshal error: %v", err)
	}
	bodyHash := cryptoimpl.Hash(bodyBytes, cryptomgr.Sha256)

	header := &common.BlockHeader{Number: BlockNumber, BodyHash: bodyHash}
	genesisBlock := &common.Block{Header: header, Body: bodyBytes}
	return genesisBlock, nil
}

// BuildQuitChainRawMessage is used to build quit chain raw message for quit chain by specifying chain id.
func (msg *ChainRawMessage) BuildQuitChainRawMessage(chainID string) (*common.RawMessage, error) {
	deleteInfo := &nodeservice.DeleteInfo{ChainId: chainID}
	payload, err := proto.Marshal(deleteInfo)
	if err != nil {
		return nil, fmt.Errorf("marshal delete info error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildJoinChainRawMessage is used to build join chain raw message for join chain by specifying genesis block bytes.
func (msg *ChainRawMessage) BuildJoinChainRawMessage(genesisBlockBytes []byte) (*common.RawMessage, error) {
	createInfo := &nodeservice.CreateInfo{GenesisBlock: genesisBlockBytes}
	payload, err := proto.Marshal(createInfo)
	if err != nil {
		return nil, fmt.Errorf("marshal create info error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildQueryChainRawMessage is used to build query chain raw message for query chain by specifying chain id.
func (msg *ChainRawMessage) BuildQueryChainRawMessage(chainID string) (*common.RawMessage, error) {
	queryInfo := &nodeservice.QueryInfo{ChainId: chainID}
	payload, err := proto.Marshal(queryInfo)
	if err != nil {
		return nil, fmt.Errorf("marshal query info error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildQueryAllChainRawMessage is used to build query all chains raw message for query all chains.
func (msg *ChainRawMessage) BuildQueryAllChainRawMessage() (*common.RawMessage, error) {
	queryInfo := &nodeservice.QueryInfo{}
	payload, err := proto.Marshal(queryInfo)
	if err != nil {
		return nil, fmt.Errorf("marshal query info error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

// BuildUpdateChainRawMessage is used to build update chain raw message for update chain.
func (msg *ChainRawMessage) BuildUpdateChainRawMessage(chainID string, txID string,
	genesisConfigPath string) (*common.RawMessage, error) {
	tx, err := msg.getVoteTransaction(chainID, txID, genesisConfigPath)
	if err != nil {
		return nil, fmt.Errorf("get transaction error: %v", err)
	}
	payload, err := proto.Marshal(tx)
	if err != nil {
		return nil, fmt.Errorf("marshal transaction error: %v", err)
	}
	rawMsg, err := msg.builder.GetRawMessage(payload)
	if err != nil {
		return nil, fmt.Errorf("get raw message error: %v", err)
	}
	return rawMsg, nil
}

func (msg *ChainRawMessage) getVoteTransaction(chainID string, txID string,
	genesisConfigPath string) (*common.Transaction, error) {
	genesisConfig, err := config.NewGenesisConfig(genesisConfigPath)
	if err != nil {
		return nil, fmt.Errorf("new genesis config error: %v", err)
	}
	chainConfig, err := genesisblock.GetChainConfig(genesisConfig, chainID)
	if err != nil {
		return nil, fmt.Errorf("get chain config error: %v", err)
	}
	chainConfigBytes, err := proto.Marshal(chainConfig)
	if err != nil {
		return nil, fmt.Errorf("marshal chain config error: %v", err)
	}
	voteTxData := &common.VoteTxData{Handler: HANDLER, Payload: chainConfigBytes}
	voteTxDataBytes, err := proto.Marshal(voteTxData)
	if err != nil {
		return nil, fmt.Errorf("marshal vote tx data error: %v", err)
	}
	txHeader := &common.TxHeader{TxId: txID, ChainId: chainID, Type: common.TxType_VOTE_TRANSACTION}
	txPayload := &common.TxPayload{Header: txHeader, Data: voteTxDataBytes}
	txPayloadBytes, err := proto.Marshal(txPayload)
	if err != nil {
		return nil, fmt.Errorf("marshal tx payload error: %v", err)
	}

	certBytes, err := msg.crypto.GetCertificate()
	if err != nil {
		return nil, fmt.Errorf("get certificate error: %v", err)
	}
	sign, err := msg.crypto.Sign(txPayloadBytes)
	if err != nil {
		return nil, fmt.Errorf("sign error: %v", err)
	}
	approval := &common.Approval{Cert: certBytes, Sign: sign}
	var approvals []*common.Approval
	approvals = append(approvals, approval)
	return &common.Transaction{Payload: txPayloadBytes, Approvals: approvals}, nil
}
