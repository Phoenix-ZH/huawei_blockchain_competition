/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package utils provide the common utils.
package utils

import (
	"crypto/rand"
	"crypto/sha256"
	"fmt"
	"math/big"
	"time"
)

const (
	// Seed is the random factor for generating tx id.
	Seed = 10000
)

// GenerateTxID is used to generate tx id.
func GenerateTxID() (string, error) {
	var result *big.Int
	var err error
	result, err = rand.Int(rand.Reader, big.NewInt(Seed))
	if err != nil {
		return "", fmt.Errorf("generate rand integer error: %v", err)
	}
	txStr := fmt.Sprintf("%d%s", time.Now().UnixNano(), result.String())
	h := sha256.New()
	_, err = h.Write([]byte(txStr))
	if err != nil {
		return "", fmt.Errorf("write bytes error: %v", err)
	}
	hashInfo := h.Sum(nil)

	hexStr := fmt.Sprintf("%x", hashInfo)
	return hexStr, nil
}
