/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package ecdsaalg

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"math/big"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"
)

type ecdsaKey struct {
	pemKey       []byte
	priKey       *ecdsa.PrivateKey
	isPrivateKey bool
	pubKey       *ecdsa.PublicKey
	curve        elliptic.Curve
	X            *big.Int
	D            *big.Int
	Y            *big.Int
}

// GetKeyFromPem get key from pem bytes.
func GetKeyFromPem(pemKey []byte) cryptomgr.Key {
	ecKey := &ecdsaKey{}
	ecKey.pemKey = pemKey
	block, _ := pem.Decode(pemKey)
	if block == nil {
		fmt.Printf("In GetKeyFromPem, the pem key is nil")
		return nil
	}

	switch block.Type {
	case "PRIVATE KEY":
		{
			ecPriKey, err := x509.ParsePKCS8PrivateKey(block.Bytes)
			if err != nil {
				fmt.Printf("ParsePKCS8PrivateKey Parse ec private key failed:%s", err.Error())
				return nil
			}
			key, ok := ecPriKey.(*ecdsa.PrivateKey)
			if !ok {
				fmt.Printf("This is not a ecdsa key")
				return nil
			}

			ecKey.priKey = key
			ecKey.pubKey = &ecKey.priKey.PublicKey
			ecKey.isPrivateKey = true
			ecKey.X = key.X
			ecKey.D = key.D
			ecKey.Y = key.Y
			ecKey.curve = key.Curve
			return ecKey
		}
	case "PUBLIC KEY":
		{
			ecPubKey, err := x509.ParsePKIXPublicKey(block.Bytes)
			if err != nil {
				fmt.Printf("Parse ec public key failed:%s", err.Error())
				return nil
			}
			pubKey, ok := ecPubKey.(*ecdsa.PublicKey)
			if !ok {
				fmt.Printf("This is not a ecdsa public key")
				return nil
			}
			ecKey.pubKey = pubKey
			ecKey.isPrivateKey = false
			ecKey.priKey = nil
			return ecKey
		}
	default:
		fmt.Printf("Unknown block type:%s", block.Type)
	}

	return nil
}

func (e *ecdsaKey) GetPemBytes() []byte {
	fmt.Printf("implement me")
	return nil
}

func (e *ecdsaKey) IsPrivate() bool {
	fmt.Printf("implement me")
	return false
}

func (e *ecdsaKey) GetPublicKey() (pubKey interface{}, err error) {
	return nil, fmt.Errorf("implement me")
}

func (e *ecdsaKey) GetPrivateKey() (priKey interface{}, err error) {
	return nil, fmt.Errorf("implement me")
}

func (e *ecdsaKey) Sign(msg []byte, hashAlg string) ([]byte, error) {
	if e.priKey == nil {
		return nil, fmt.Errorf("private key is nil")
	}
	digest := Hash(msg)
	bytes, err := e.priKey.Sign(rand.Reader, digest, nil)
	if err != nil {
		return nil, err
	}

	return bytes, nil
}

func (e *ecdsaKey) Verify(msg []byte, signature []byte, hashAlg string) error {
	return fmt.Errorf("implement me")
}
