/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package ecdsaalg provide the implementation of ecdsa crypto.
package ecdsaalg

import (
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"time"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"
)

type ecdsacert struct {
	pemCert []byte
	cert    *x509.Certificate
}

// GetCert get certificate from pem bytes.
func GetCert(pemCert []byte) cryptomgr.Cert {
	if pemCert == nil {
		return nil
	}
	eccert := &ecdsacert{}
	eccert.pemCert = pemCert
	block, _ := pem.Decode(pemCert)

	if block == nil {
		fmt.Printf("In GetCert, the pem decode failed.")
		panic("In GetCert, the pem decode failed.")
	}
	x509cert, err := x509.ParseCertificate(block.Bytes)
	if err != nil {
		return nil
	}
	eccert.cert = x509cert
	return eccert
}

func (e *ecdsacert) GetCommonName() string {
	panic("implement me")
}

func (e *ecdsacert) GetExpireTime() time.Time {
	panic("implement me")
}

func (e *ecdsacert) GetOrganizationalUnit() []string {
	panic("implement me")
}

func (e *ecdsacert) GetOrganization() []string {
	panic("implement me")
}

func (e *ecdsacert) Verify(msg []byte, signature []byte, hashOpt string) error {
	panic("implement me")
}

func (e *ecdsacert) CheckValidation(rootcerts []cryptomgr.Cert) (string, error) {
	panic("implement me")
}

func (e *ecdsacert) GetPemCertBytes() []byte {
	return e.pemCert
}

func (e *ecdsacert) GetX509Cert() *x509.Certificate {
	panic("implement me")
}

func (e *ecdsacert) GetFingerPrint() string {
	panic("implement me")
}
