/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package cryptomgr is the implementation of security.
package cryptomgr

import (
	"crypto/x509"
	"math/big"
	"time"
)

// Crypto is the definition of crypto interface.
type Crypto interface {
	Sign(message []byte) ([]byte, error)
	GetCertificate() ([]byte, error)
}

//对于签名，我们需要用wnode节点本地的私钥进行签名

//对于验签，如果是链外请求（比如创建链，查询链），需要用wnode节点本地的CA证书验证消息中证书的可靠性，保证请求者是本节点所属组织的管理员

//对于验签，如果是链内请求，需要用链上的各个组织内的CA验证消息中证书的可靠性

// Symmetric key type
const (
	AES256 string = "aes_256"
	SM4    string = "sm4"
)

const (
	// Sm2WithSm3  gm sign algorithm
	Sm2WithSm3 = "sm2_with_sm3"
	// EcdsaWithSha256 ecdsa sign algorithm
	EcdsaWithSha256 = "ecdsa_with_sha256"
	// Ed25519 ed25519 sign algorithm
	Ed25519 = "ed25519"
	// Sm3 sm3 hash algorithm
	Sm3 = "sm3"
	// Sha256 sha256 hash algorithm
	Sha256 = "sha256"
)

// ECDSASignature ecdsa signature struct with R and S.
type ECDSASignature struct {
	R, S *big.Int
}

// Key describe the key
type Key interface {
	//GetType() string
	GetPemBytes() []byte

	IsPrivate() bool

	GetPublicKey() (pubKey interface{}, err error)

	GetPrivateKey() (priKey interface{}, err error)

	Sign

	Verify
}

// Sign sign interface.
type Sign interface {
	Sign(msg []byte, hashAlg string) ([]byte, error)
}

// Verify verify interface.
type Verify interface {
	Verify(msg []byte, signature []byte, hashAlg string) error
}

// Encrypt encrypt interface.
type Encrypt interface {
	Encrypt(plainText []byte) (cipherText string, nonce string)
}

// Decrypt decrypt interface.
type Decrypt interface {
	Decrypt(cipherText string, nonce string) (plainText string)
}

// Cert describe the certificate
type Cert interface {
	GetCommonName() string
	GetExpireTime() time.Time
	GetOrganizationalUnit() []string
	GetOrganization() []string
	Verify(msg []byte, signature []byte, hashOpt string) error
	CheckValidation(rootcerts []Cert) (string, error)
	GetPemCertBytes() []byte
	GetX509Cert() *x509.Certificate
	GetFingerPrint() string
}

// Identity the local key and cert api
type Identity interface {

	// Sign the msg by local key
	Sign(msg []byte) (signature []byte, err error)

	// Get the local cert to filling the signature structure
	GetLocalCert() []byte

	// Verify the signature for the msg by certificate
	Verify(msg []byte, sig []byte, cert []byte) bool

	// Return the CA name and validate result
	Validate(cert []byte) (string, error)

	// Check whether the local certificate is signed by the root cert
	CheckLocalCertSignature(rootCert []byte) bool

	// Get node org name
	GetOrgName() string
}
