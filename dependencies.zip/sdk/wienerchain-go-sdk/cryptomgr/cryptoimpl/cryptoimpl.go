/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package cryptoimpl provide the implementation of crypto.
package cryptoimpl

import (
	"sync"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"
	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr/ecdsaalg"
	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr/gmalg"
)

// CryptoInfo is the definition of CryptoInfo
type CryptoInfo struct {
	alg  string
	cert cryptomgr.Cert
	key  cryptomgr.Key
}

var cryptoInfo *CryptoInfo
var once sync.Once

// Sign is used to sign for a message.
func (c *CryptoInfo) Sign(message []byte) ([]byte, error) {
	return c.key.Sign(message, c.alg)
}

// GetCertificate is used to get certificate.
func (c *CryptoInfo) GetCertificate() ([]byte, error) {
	return c.cert.GetPemCertBytes(), nil
}

// NewCrypto is used to new an instance of crypto.
func NewCrypto(alg string, certPath string, keyPath string) cryptomgr.Crypto {
	once.Do(
		func() {
			ci := &CryptoInfo{}

			keyPem := GetPemInfoFromPath(keyPath)
			key := CreateKeyFromPemWithAlg(keyPem, alg)
			ci.key = key

			certPem := GetPemInfoFromPath(certPath)
			cert := CreateCertFromPemWithAlg(certPem, alg)
			ci.cert = cert

			ci.alg = alg
			cryptoInfo = ci
		})

	return cryptoInfo
}

// CreateCertFromPemWithAlg get certificate from pem bytes.
func CreateCertFromPemWithAlg(pemCert []byte, alg string) cryptomgr.Cert {
	switch alg {
	case cryptomgr.Sm2WithSm3:
		return gmalg.GetCert(pemCert)
	case cryptomgr.EcdsaWithSha256:
		return ecdsaalg.GetCert(pemCert)
	default:
		return ecdsaalg.GetCert(pemCert)
	}
}

// CreateKeyFromPemWithAlg is used to create private key from pem bytes with alg.
func CreateKeyFromPemWithAlg(pemKey []byte, alg string) cryptomgr.Key {
	switch alg {
	case cryptomgr.Sm2WithSm3:
		return gmalg.GetPriKey(pemKey)
	case cryptomgr.EcdsaWithSha256:
		return ecdsaalg.GetKeyFromPem(pemKey)
	default:
		return ecdsaalg.GetKeyFromPem(pemKey)
	}
}
