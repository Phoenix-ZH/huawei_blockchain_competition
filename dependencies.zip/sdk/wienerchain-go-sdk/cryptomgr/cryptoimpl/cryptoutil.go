/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package cryptoimpl provide the implementation of crypto.
package cryptoimpl

import (
	"fmt"
	"io/ioutil"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr/ecdsaalg"
	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr/gmalg"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"
)

// GetPemInfoFromPath get pem info from path.
func GetPemInfoFromPath(path string) []byte {
	//todo need to support key with password
	if path == "" {
		return nil
	}
	info, err := ioutil.ReadFile(cleanPath(path))
	if err != nil {
		fmt.Printf("Read pem file failed:%s", err.Error())
		return nil
	}

	return info
}

func cleanPath(filePath string) string {
	return filePath
}

// Hash get hash for msg with certain algorithm.
func Hash(msg []byte, algorithm string) []byte {
	switch algorithm {
	case cryptomgr.Sha256, "":
		return ecdsaalg.Hash(msg)
	case cryptomgr.Sm3:
		return gmalg.Hash(msg)
	default:
		return nil
	}
}
