/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package gmalg the gm algorithm for generate of certificate and key
package gmalg

import (
	"fmt"

	"gmssl"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"
)

type gmKey struct {
	isPrivate bool
	priKey    *gmssl.PrivateKey
	priKeyPem []byte
	pubKey    *gmssl.PublicKey
	pubKeyPem []byte
}

const (
	ecParamgenCurve = "ec_paramgen_curve"
	sm2Curve        = "sm2p256v1"
	ecParamEnc      = "ec_param_enc"
	namedCurve      = "named_curve"
	ecAlg           = "EC"
	cipher          = "SMS4"
)

// GeneratePriKey generate private key
func GeneratePriKey() cryptomgr.Key {
	sm2keygenargs := [][2]string{
		{ecParamgenCurve, sm2Curve},
		{ecParamEnc, namedCurve},
	}
	sm2Key, err := gmssl.GeneratePrivateKey(ecAlg, sm2keygenargs, nil)
	if err != nil {
		return nil
	}
	pemSm2Key, err := sm2Key.GetPEM(cipher, "")
	if err != nil {
		return nil
	}
	priKey := GetPriKey([]byte(pemSm2Key))
	return priKey
}

// GetPubKey generate public key from pem
func GetPubKey(pemKey []byte) cryptomgr.Key {
	key := &gmKey{}
	publicKey, err := gmssl.NewPublicKeyFromPEM(string(pemKey))
	if err != nil {
		fmt.Printf("This is not a gm public key.")
		return nil
	}

	key.pubKey = publicKey
	key.pubKeyPem = pemKey
	key.isPrivate = false
	return key
}

// GetPriKey generate private key from pem
func GetPriKey(pemKey []byte) cryptomgr.Key {
	key := &gmKey{}
	privateKey, err := gmssl.NewPrivateKeyFromPEM(string(pemKey), "")
	if err != nil {
		return nil
	}
	key.priKey = privateKey
	key.priKeyPem = pemKey
	publicKeyPEM, err := privateKey.GetPublicKeyPEM()
	if err != nil {
		fmt.Printf("Get gm public key from private key failed")
		return nil
	}
	key.pubKeyPem = []byte(publicKeyPEM)
	publicKey, err := gmssl.NewPublicKeyFromPEM(string(key.pubKeyPem))
	if err != nil {
		fmt.Printf("Generate gm public key from pem publie key failed")
		return nil
	}
	key.pubKey = publicKey
	key.isPrivate = true
	return key
}

// GetPemBytes get pem bytes
func (g *gmKey) GetPemBytes() []byte {
	if g.isPrivate {
		return g.priKeyPem
	}
	return g.pubKeyPem
}

// IsSymmetric is symmetric
func (g *gmKey) IsSymmetric() bool {
	panic("implement me")
}

// IsPrivate is private key
func (g *gmKey) IsPrivate() bool {
	return g.isPrivate
}

// GetPublicKey get public key
func (g *gmKey) GetPublicKey() (pubKey interface{}, err error) {
	return g.pubKey, nil
}

// GetPrivateKey get private key
func (g *gmKey) GetPrivateKey() (priKey interface{}, err error) {
	return g.priKey, nil
}

// Sign sign the message
func (g *gmKey) Sign(msg []byte, hashAlg string) ([]byte, error) {
	if !g.isPrivate {
		return nil, fmt.Errorf("this is not private key")
	}
	digest := calcSm2SignDigest(g.pubKey, msg)

	sig, err := g.priKey.Sign(sm2SignFlag, digest, nil)
	if err != nil {
		return nil, fmt.Errorf("sign error")
	}
	return sig, nil
}

// Verify verify the message
func (g *gmKey) Verify(msg []byte, signature []byte, hashAlg string) error {
	digest := calcSm2SignDigest(g.pubKey, msg)
	err := g.pubKey.Verify(sm2SignFlag, digest, signature, nil)
	return err
}

func calcSm2SignDigest(sm2pk *gmssl.PublicKey, message []byte) []byte {
	sm3ctx, _ := gmssl.NewDigestContext(sm3HashFlag)
	sm2zid, _ := sm2pk.ComputeSM2IDDigest(defaultSm2ID)
	err := sm3ctx.Reset()
	if err != nil {
		fmt.Printf("Reset sm3 ctx failed")
		return nil
	}
	err = sm3ctx.Update(sm2zid)
	if err != nil {
		fmt.Printf("Update sm3 failed for sm2zid")
		return nil
	}
	err = sm3ctx.Update(message)
	if err != nil {
		fmt.Printf("Update sm3 failed for message")
		return nil
	}

	hashRes, err := sm3ctx.Final()
	if err != nil {
		fmt.Printf("Final sm3 failed")
		return nil
	}
	return hashRes
}
