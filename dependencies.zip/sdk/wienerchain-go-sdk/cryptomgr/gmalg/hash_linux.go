/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package gmalg the gm algorithm for generate of certificate and key
package gmalg

import (
	"fmt"
	"strings"

	"gmssl"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"
)

const sm3HashFlag = "SM3"

// Hash is used to compute hash value for a message.
func Hash(msg []byte) []byte {
	sm3ctx, err := gmssl.NewDigestContext(strings.ToUpper(cryptomgr.Sm3))
	if err != nil {
		fmt.Printf("New sm3 digest context failed:%s", err.Error())
		return nil
	}
	err = sm3ctx.Reset()
	if err != nil {
		fmt.Printf("Sm3 context reset failed:%s", err.Error())
		return nil
	}
	err = sm3ctx.Update(msg)
	if err != nil {
		fmt.Printf("Sm3 context update message failed:%s", err.Error())
		return nil
	}
	sm3Hash, err := sm3ctx.Final()
	if err != nil {
		fmt.Printf("Sm3 ctx final failed:%s", err.Error())
		return nil
	}
	return sm3Hash
}
