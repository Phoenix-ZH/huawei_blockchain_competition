/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package gmalg

import (
	"crypto/x509"
	"fmt"
	"gmssl"
	"strings"
	"time"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"
)

type gmcert struct {
	pemCert           []byte
	gmsslCert         *gmssl.Certificate
	pubKey            *gmssl.PublicKey
	subjectCN         string
	subjectOU         string
	subjectO          string
	subjectPostalCode string
	subjectStreet     string
	subjectLocality   string
	subjectCountry    string
}

const sm2SignFlag = "sm2sign"
const defaultSm2ID = "1234567812345678"

// GetCert create certificate from pem
func GetCert(pem []byte) cryptomgr.Cert {
	certificate, err := gmssl.NewCertificateFromPEM(string(pem), "")
	if err != nil {
		fmt.Printf("change gm pem to certificate failed:%s", err.Error())
		return nil
	}

	cert := gmcert{}
	cert.pemCert = pem
	cert.gmsslCert = certificate
	cert.setSubjects()
	publicKey, err := cert.gmsslCert.GetPublicKey()
	if err != nil {
		fmt.Printf("Get public key failed from gm certificate.")
		return nil
	}
	cert.pubKey = publicKey
	return &cert
}

func (g *gmcert) setSubjects() {
	subject, err := g.gmsslCert.GetSubject()
	if err != nil {
		return
	}
	subjects := strings.Split(subject, "/")
	for _, v := range subjects {
		index := strings.Index(v, "=")
		if index == -1 {
			continue
		}
		subjectLabel := v[:index]
		resStr := v[index+1:]
		switch subjectLabel {
		case "CN":
			g.subjectCN = resStr
		case "OU":
			g.subjectOU = resStr
		case "O":
			g.subjectO = resStr
		case "postalCode":
			g.subjectPostalCode = resStr
		case "street":
			g.subjectStreet = resStr
		case "L":
			g.subjectLocality = resStr
		case "ST":
			g.subjectStreet = resStr
		case "C":
			g.subjectCountry = resStr
		default:
			fmt.Printf("Unknown subject")
		}
	}
}

// GetCommonName get common name
func (g *gmcert) GetCommonName() string {
	if g.gmsslCert == nil {
		return ""
	}
	return g.subjectCN
}

// GetExpireTime get expire time
func (g *gmcert) GetExpireTime() time.Time {
	panic("implement me")
}

// GetOrganizationalUnit get organization unit
func (g *gmcert) GetOrganizationalUnit() []string {
	if g.gmsslCert == nil {
		return nil
	}
	return []string{g.subjectOU}
}

// GetOrganization get organization
func (g *gmcert) GetOrganization() []string {
	if g.gmsslCert == nil {
		return nil
	}
	return []string{g.subjectO}
}

// Verify verify the message signature
func (g *gmcert) Verify(msg []byte, signature []byte, hashOpt string) error {
	digest := calcSm2SignDigest(g.pubKey, msg)
	err := g.pubKey.Verify(sm2SignFlag, digest, signature, nil)
	return err
}

// CheckValidation check validation
func (g *gmcert) CheckValidation(rootcerts []cryptomgr.Cert) (string, error) {
	for _, rootCert := range rootcerts {
		gmRootCert, ok := rootCert.(*gmcert)
		if !ok {
			continue
		}
		verifyRes := g.gmsslCert.VerifyCert(gmRootCert.gmsslCert)
		if verifyRes {
			return gmRootCert.subjectO, nil
		}
	}

	return "", fmt.Errorf("verify certificate failed by root certs")
}

// GetPemCertBytes get pem bytes
func (g *gmcert) GetPemCertBytes() []byte {
	return g.pemCert
}

// GetX509Cert get x509 certificate
func (g *gmcert) GetX509Cert() *x509.Certificate {
	return nil
}

// GetFingerPrint get finger print
func (g *gmcert) GetFingerPrint() string {
	return g.gmsslCert.GetFingerPrint()
}
