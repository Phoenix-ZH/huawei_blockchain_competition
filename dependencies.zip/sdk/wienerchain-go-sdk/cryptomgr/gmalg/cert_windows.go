/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package gmalg the gm algorithm for generate of certificate and key
package gmalg

import (
	"crypto/x509"
	"time"

	"git.huawei.com/poissonsearch/wienerchain/wienerchain-go-sdk/cryptomgr"
)

// Gmcert gm certificate
type Gmcert struct {
}

// GenerateSelfSignCert create self signed certificate
func GenerateSelfSignCert(country, province, locality, org, ou, streetAddress, postalCode, commonName string,
	key cryptomgr.Key) cryptomgr.Cert {
	return nil
}

// GetCert create certificate from pem
func GetCert(pem []byte) cryptomgr.Cert {
	return nil
}

// GetCommonName get common name
func (g *Gmcert) GetCommonName() string {
	return ""
}

// GetExpireTime get expire time
func (g *Gmcert) GetExpireTime() time.Time {
	panic("implement me")
}

// GetOrganizationalUnit get organization unit
func (g *Gmcert) GetOrganizationalUnit() []string {
	return nil
}

// GetOrganization get organization
func (g *Gmcert) GetOrganization() []string {
	return nil
}

// Verify verify the message signature
func (g *Gmcert) Verify(msg []byte, signature []byte, hashOpt string) error {
	return nil
}

// CheckValidation check validation
func (g *Gmcert) CheckValidation(rootcerts []cryptomgr.Cert) (string, error) {
	return "", nil
}

// GetPemCertBytes get pem bytes
func (g *Gmcert) GetPemCertBytes() []byte {
	return nil
}

// GetX509Cert get x509 certificate
func (g *Gmcert) GetX509Cert() *x509.Certificate {
	return nil
}

// GetFingerPrint get finger print
func (g *Gmcert) GetFingerPrint() string {
	return ""
}
