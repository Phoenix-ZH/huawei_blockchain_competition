/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// Package gmalg the gm algorithm for generate of certificate and key
package gmalg

import "crypto/sha256"

// Hash is used to compute hash value for a message.
func Hash(msg []byte) []byte {
	h := sha256.New()
	_, err := h.Write(msg)
	if err != nil {
		return nil
	}
	hashInfo := h.Sum(nil)
	return hashInfo
}
