// 集成go-sdk注意事项
1、拷贝lib目录下的openssl文件夹到/usr/local/include
2、保证proto、thirdparty包和wienerchain-go-sdk包在平级目录下，使go module可以正常引用到相关依赖
3、App集成go sdk，进行go build编译时，增加-a编译选项，保证所有代码可强制重新编译