#!/bin/bash

# **************************************************************************************************************
# Copyright: (c) Huawei Technologies Co., Ltd. 2020. All rights reserved.
# Script for generating .pb.go source code from .proto file.
# Version: 1.0.0
# Author: l00500029
# Usage:
#    1). use for single .proto file
#        bash build_go.sh ${proto_file_path}
#    2). use for .proto file directory
#        bash build_go.sh ${proto_dir_path}
#    3). Default: generate .pb.go file for pb sub directory under current direcotry (if present).
#        bash build_go.sh 
# Note: both absolute and relative path support. but all of the .proto file must unber pb or pb's subdirectory.
# **************************************************************************************************************

function generate_single_pb_go() {
    local CUR_DIR=`pwd`
    local file_path=$1
    local dir_path=`cd $(dirname $file_path); pwd`
    local file_name=$(basename $file_path)
    local abs_path=${dir_path}/${file_name}
    local WORK_DIR=${abs_path%pb*}
    local src_path=${WORK_DIR}pb
    local go_out_path=${WORK_DIR}go

    if [ ! -d "${go_out_path}" ]; then 
        mkdir -p ${go_out_path}
    fi
    
    cd ${WORK_DIR}
    protoc -I=${src_path} --go_out=plugins=grpc,paths=source_relative:go ${abs_path}
    cd ${CUR_DIR}
}

if [ $# == 0 ]; then 
    CUR_DIR=`pwd`
    PROTO_PATH=${CUR_DIR}/pb
    
    if [ ! -d "${PROTO_PATH}" ]; then
        echo "Error: current directory does not contain pb subdirectory, please specify a proto file path or directory and try again."
        exit 1
    fi
fi

if [ $# == 1 ]; then 
    PROTO_PATH=$1
fi

if [ -f "${PROTO_PATH}" ]; then
    generate_single_pb_go ${PROTO_PATH}
    exit 0
fi

if [ -d "${PROTO_PATH}" ]; then 
    for proto_file in `find $PROTO_PATH -name '*.proto'`; do
        generate_single_pb_go ${proto_file}
    done
    exit 0
fi

