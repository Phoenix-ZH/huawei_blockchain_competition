## <center>pb.go源码生成工具使用指南</center>
#### 1. 环境搭建
1. 从.proto文件生成go源码文件需要proto编译工具protoc，和编译工具go语言插件protoc-gen-go:  
   + 当前protoc的最新版本为：v3.11.4
   + 当前protoc-gen-go的最新版本：v1.3.4
   + 本工具使用的均为最新版本。

2. 获取protoc和protoc-gen-go
   + 从附件中获取: 附件中已包含编译好的最新版本的protoc和protoc-gen-go的可执行文件: <u>[博客附件](http://3ms.huawei.com/km/groups/3309741/blogs/details/7903105)</u>
   + 从github上获取：
      - protoc： <u>[https://github.com/protocolbuffers/protobuf](https://github.com/protocolbuffers/protobuf)</u>
      - protoc-gen-go: <u>[https://github.com/golang/protobuf](https://github.com/golang/protobuf)</u>

3. 将protoc和protoc-gen-go的可执行文件拷贝到\$GOPATH/bin目录下，并将附件中的google目录复制到\$GOPATH/include目录下（include目录不存在时，手动创建），最后将\$GOPATH/bin添加到PATH

#### 2. 使用方法
1. 单个proto文件生成go
    ```bash
    bash build_go.sh ${proto_file_path}
    ```
2. 批量生成go
    ```bash
    bash build_go.sh ${proto_dir_path}
    ```
3. 参数缺失：为当前目录下的pb子目录中的所有proto文件批量生成go
    ```bash
    bash build_go.sh
    ```
4. 注意： 对于参数，绝对路径和相对路径都是支持的，但是所有的proto文件必须置于pb的子目录（或子目录的子目录）下。