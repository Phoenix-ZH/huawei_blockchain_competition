package consensus

func FormFirstPosition() *Position {
	return &Position{
		Type: &Position_Description_{
			Description: Position_FIRST,
		},
	}
}

func FormLastPosition() *Position {
	return &Position{
		Type: &Position_Description_{
			Description: Position_LAST,
		},
	}
}

func FormSpecifiedPosition(n uint64) *Position {
	return &Position{
		Type: &Position_Specified_{
			Specified: &Position_Specified{
				BlockNumber: n,
			},
		},
	}
}
