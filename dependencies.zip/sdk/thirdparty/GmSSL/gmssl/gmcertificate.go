/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

// gmssl: Before compile the wnode, copy this file to the open source gmssl folder as a patch!
package gmssl

/*
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/x509.h>
#include <openssl/ec.h>
#include <openssl/sm2.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/engine.h>
#include <openssl/objects.h>
#include <openssl/opensslconf.h>

extern long _BIO_get_mem_data(BIO *b, char **pp);
extern void _OPENSSL_free(void *addr);


void GetFingerPrintf(X509* x, void* fingerPrintBuf, uint* bufLen)
{
   unsigned char         md[EVP_MAX_MD_SIZE] = {0};
   unsigned int          n;
   const EVP_MD        * digest;
   int                   pos;

   //todo modify the sha1 to sha256
   digest = EVP_get_digestbyname("sha1");
   X509_digest(x, digest, md, &n);
    if (*bufLen > EVP_MAX_MD_SIZE){
	    return;
    }
    memcpy(fingerPrintBuf, md, 20);
    *bufLen = 20;

   for(pos = 0; pos < 19; pos++){
      printf("%02x:", md[pos]);
   }

}

int VerifyCert(X509 *cert, X509 *cacert)
{
     int ret;
     X509_STORE *store;
     X509_STORE_CTX *ctx;

     store = X509_STORE_new();
     X509_STORE_add_cert(store, cacert);

     ctx = X509_STORE_CTX_new();
     X509_STORE_CTX_init(ctx, store, cert, NULL);

     ret = X509_verify_cert(ctx);
    return ret;
}
// 传入私钥（内含公钥）
X509 * GenerateSelfSignCert(void* country, void* province, void* locality, void* org, void* ou, void* commonName, EVP_PKEY *pkey){
    X509 * x509;
    x509 = X509_new();
//todo serial number should be changed

    ASN1_INTEGER_set(X509_get_serialNumber(x509), 1);
    X509_gmtime_adj(X509_get_notBefore(x509), 0);

//todo 20年有效期

    X509_gmtime_adj(X509_get_notAfter(x509), 315360000*2L);
    X509_set_pubkey(x509, pkey);

    X509_NAME * name;
    name = X509_get_subject_name(x509);

    X509_NAME_add_entry_by_txt(name, "C",  MBSTRING_ASC,
                           (unsigned char *)country, -1, -1, 0);
    X509_NAME_add_entry_by_txt(name, "ST", MBSTRING_ASC,
                           (unsigned char *)province, -1, -1, 0);
    X509_NAME_add_entry_by_txt(name, "L", MBSTRING_ASC,
                           (unsigned char *)locality, -1, -1, 0);
    X509_NAME_add_entry_by_txt(name, "O",  MBSTRING_ASC,
                           (unsigned char *)org, -1, -1, 0);
    X509_NAME_add_entry_by_txt(name, "OU",  MBSTRING_ASC,
                           (unsigned char *)ou, -1, -1, 0);
    X509_NAME_add_entry_by_txt(name, "CN", MBSTRING_ASC,
                           (unsigned char *)commonName, -1, -1, 0);

	X509_set_issuer_name(x509, name);

//todo maybe sha256
	X509_sign(x509, pkey, EVP_sha1());

    return x509;
}


void X509_to_PEM(X509 *cert, void* pemBuf, uint* pemBufLen) {
    BIO *bio = NULL;
    char *pem = NULL;

    if (NULL == cert) {
        return ;
    }

    bio = BIO_new(BIO_s_mem());
    if (NULL == bio) {
        return ;
    }

    if (0 == PEM_write_bio_X509(bio, cert)) {
        BIO_free(bio);
        return ;
    }

    BUF_MEM *mem = NULL;
    BIO_get_mem_ptr(bio, &mem);

    if (*pemBufLen <= mem->length){
       return;
    }
    memcpy(pemBuf, mem->data, mem->length);
    *pemBufLen = mem->length;
    BIO_set_close(bio, BIO_NOCLOSE);
    BIO_free(bio);
    return ;
}
*/
import "C"
import (
	"fmt"
	"unsafe"
)

// GetFingerPrint get finger print of certificate
func (cert *Certificate) GetFingerPrint() string {
	var fingerPrintBuf [64]byte
	var bufLen C.uint
	var fingerPrint string
	C.GetFingerPrintf(cert.x509, unsafe.Pointer(&fingerPrintBuf), (*C.uint)(&bufLen))
	len := int(bufLen)
	for i := 0; i < len-1; i++ {
		item := fmt.Sprintf("%02x:", fingerPrintBuf[i])
		fingerPrint = fingerPrint + item
	}
	fingerPrint = fingerPrint + fmt.Sprintf("%02x", fingerPrintBuf[len-1])
	return fingerPrint
}

// VerifyCert verify cert with CA cert
func (cert *Certificate) VerifyCert(caCert *Certificate) bool {
	var res C.int
	res = C.VerifyCert(cert.x509, caCert.x509)

	if res == 1 {
		return true
	}
	return false
}

// GenerateSelfSignCert generate self sign certificate
func GenerateSelfSignCert(country, province, locality, org, ou, streetAddress, postalCode,
	commonName string, key *PrivateKey) (*Certificate, error) {
	cCountry := C.CString(country)
	defer C.free(unsafe.Pointer(cCountry))
	cProvince := C.CString(province)
	defer C.free(unsafe.Pointer(cProvince))
	cLocality := C.CString(locality)
	defer C.free(unsafe.Pointer(cLocality))
	cOrg := C.CString(org)
	defer C.free(unsafe.Pointer(cOrg))
	cOu := C.CString(ou)
	defer C.free(unsafe.Pointer(cOu))
	cCommonName := C.CString(commonName)
	defer C.free(unsafe.Pointer(cCommonName))

	sm2Key := key
	x509 := C.GenerateSelfSignCert(unsafe.Pointer(cCountry), unsafe.Pointer(cProvince), unsafe.Pointer(cLocality), unsafe.Pointer(cOrg), unsafe.Pointer(cOu), unsafe.Pointer(cCommonName), sm2Key.pkey) ///nolint
	cert := &Certificate{}
	cert.x509 = x509
	return cert, nil
}

// GetPemFromCert get pem from cert
func GetPemFromCert(certificate *Certificate) []byte {
	var pemBuf [1024]byte
	var pemBufLen C.uint = 1024
	C.X509_to_PEM(certificate.x509, unsafe.Pointer(&pemBuf), (*C.uint)(&pemBufLen))

	pemCert := pemBuf[:pemBufLen]
	return pemCert
}
